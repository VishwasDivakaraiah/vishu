<?php
session_start();
?>

<!doctype html>
<html lang=''>
<head>
     <link rel="stylesheet" href="styles.css">
     <link rel="stylesheet" type="text/css" href="css/viewtablesearch.css" />
   <title>VIEW Student</title>
<style>
.form1{
margin-left:200px;
margin-right:200px;
border:1px solid white; 
padding-left:25px;
padding-top:10px;
padding-bottom:10px;
}
</style>

</head>

<body bgcolor=black text=white>


<h1><u><center>Student Management System</center></u></h1><div id='cssmenu'>

<ul>

   <li> <a  href='home.php' ><span>Home</span></a></li>
 
   <li class='active has-sub'><ul><li class='has-sub'></li></ul></li>
   <li><a href='Add_student.php'><span>Add Student</span></a></li>
   <li><a style="background-color:grey;" href='View_student.php'><span>View Student</span></a></li>
   
   <li class='last'>
        <a href='contact.html'><span>Contact</span></a></li>
   <li><a href='help.html'><span>Help</span></a></li>

    <li></li>


<li class='active has-sub'>
<a style="text-transform:uppercase;" href='#'><span><?php
if($_SESSION["user"]){
	?>
	WELCOME <?php echo $_SESSION["user"]; ?>

<?php
}
	?></span></a>
     
                       <ul>
         <li class='has-sub'>
                         
 <li><a href="logout.php?logout"><span>Log Out</span></a></li>

                                                    <ul>
              
            </ul>
         </li>
</li>


</ul>
</div>
<center><h2>View Student Details</h2>

	<br/>
	<div class="search">
	<form method="post" action="searchidandname.php">
    <select name="cbosearch">
    	<option>ID</option>
    	<option>Name</option>
      
    </select>
	<input type="text" name="txtsearch" placeholder="Type to Search" required/><input type="submit" name="cmdsearch" value="Search" />
    </form>
	
    </div>
	<br/>
	<br/>
	<br/>
	<table>
    		<tr>
            <th>StuID</th>
            <th>StuName</th>
            <th>email</th>
            <th>Branch</th>
            <th>Address</th>
            <th>Ph No.</th>
            <th>Gender</th>
          
           
            <th>Option</th>
        </tr>
		
        <?php
		    
			include "dbconnect.php";
			$user=$_SESSION["user"];
			
			$i = "select * from `".$user."`";
			$h = mysql_query($i);
			while($tr=mysql_fetch_array($h))
			{
		?>
        <tr>
        	<td><?php echo $tr[0]; ?></td>
            <td><?php echo $tr[1]; ?></td>
            <td><?php echo $tr[2]; ?></td>
            <td><?php echo $tr[3]; ?></td>
            <td><?php echo $tr[4]; ?></td>
            <td><?php echo $tr[5]; ?></td>
            <td><?php echo $tr[6]; ?></td>
           
          
		
               <td><a href="edit.php?id=<?php echo $tr[0];?>">Edit</a>/<a href="delete.php?id=<?php echo $tr[0];?>">Delete</a></td>
	

	   </tr>
        <?php
			}
		?>
		
    </table>

<marquee><u><b>Nitte Meenakshi Institute Of Technology</b></u></marquee>

</body>
<html>



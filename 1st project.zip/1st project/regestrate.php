<?php
	ob_start();
	session_start();
	if( isset($_SESSION['user'])!="" ){
		header("Location: home.php");
	}
	include_once 'dbconnect.php';

	$error = false;

	if ( isset($_POST['btn-signup']) ) {
		
		// clean user inputs to prevent sql injections
		$name = trim($_POST['name']);
		$name = strip_tags($name);
		$name = htmlspecialchars($name);
		
		$email = trim($_POST['email']);
		$email = strip_tags($email);
		$email = htmlspecialchars($email);
		
		$pass = trim($_POST['pass']);
		$pass = strip_tags($pass);
		$pass = htmlspecialchars($pass);
		
		$hint = trim($_POST['hint']);
		$hint = strip_tags($hint);
		$hint = htmlspecialchars($hint);
		
		// basic name validation
		if (empty($name)) {
			$error = true;
			$nameError = "Please enter your full name.";
		} else if (strlen($name) < 3) {
			$error = true;
			$nameError = "Name must have atleat 3 characters.";
		} else if (!preg_match("/^[a-zA-Z ]+$/",$name)) {
			$error = true;
			$nameError = "Name must contain alphabets and space.";
		}
		
		
		// basic hint validation
		if (empty($hint)) {
			$error = true;
			$nameError = "Please enter your full name.";
		} else if (strlen($name) < 3) {
			$error = true;
			$nameError = "Name must have atleat 3 characters.";
		} else if (!preg_match("/^[a-zA-Z ]+$/",$name)) {
			$error = true;
			$nameError = "Name must contain alphabets and space.";
		}
		
		//basic email validation
		if ( !filter_var($email,FILTER_VALIDATE_EMAIL) ) {
			$error = true;
			$emailError = "Please enter valid email address.";
		} else {
			// check email exist or not
			$query = "SELECT username FROM login WHERE username='$email'";
			$result = mysql_query($query);
			$count = mysql_num_rows($result);
			if($count!=0){
				$error = true;
				$emailError = "Provided Email is already in use.";
			}
		}
		// password validation
		if (empty($pass)){
			$error = true;
			$passError = "Please enter password.";
		} else if(strlen($pass) < 6) {
			$error = true;
			$passError = "Password must have atleast 6 characters.";
		}
		
		// password encrypt using SHA256();
		
		
		// if there's no error, continue to signup
		if( !$error ) {
			
			$query = "INSERT INTO login(username,userid,password,hint) VALUES('$name','$email','$pass','$hint')";
			$res = mysql_query($query);
				
			if ($res) {
				$errTyp = "success";
				$errMSG = "Successfully registered, you may login now";
				unset($name);
				unset($email);
				unset($pass);
				$name = mysql_real_escape_string($_POST['name']);
				$sql = "CREATE TABLE `".$name."`( ".
       "id INT(11) NOT NULL AUTO_INCREMENT, ".
       "name VARCHAR(50) NOT NULL, ".
       "email VARCHAR(50) NOT NULL, ".
       "branch VARCHAR(50) NOT NULL, ".
	   "address VARCHAR(255) NOT NULL, ".
	   "mobile BIGINT(20), ".
	   "gender enum('m','f') NOT NULL, ".
	   "image VARCHAR(255) NOT NULL, ".
	   "dob date NOT NULL, ".
	   "regDate DATETIME NOT NULL, ".
       "PRIMARY KEY ( id )); ";
 
mysql_select_db( 'TUTORIALS' );

$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not create table: ' . mysql_error());
}
echo "Table created successfully\n";
mysql_close($conn);


				
				
				
			} else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";	
			}	
				
		}
		
		
	}
?>




<!doctype html>
<html lang=''>
<head>
     <link rel="stylesheet" href="styles.css">
     
   <title>Sign Up</title>
<style>
.form1{
margin-left:200px;
margin-right:200px;
border:1px solid white; 
padding-left:25px;
padding-top:10px;
padding-bottom:10px;
}
.she{
padding-left:5px;
font-size:bold;
}

.btn {
  background: #3498db;
  background-image: -webkit-linear-gradient(top, #3498db, #2980b9);
  background-image: -moz-linear-gradient(top, #3498db, #2980b9);
  background-image: -ms-linear-gradient(top, #3498db, #2980b9);
  background-image: -o-linear-gradient(top, #3498db, #2980b9);
  background-image: linear-gradient(to bottom, #3498db, #2980b9);
  -webkit-border-radius: 8;
  -moz-border-radius: 8;
  border-radius: 8px;
  font-family: Arial;
  color: #ffffff;
  font-size: 13px;
 
  text-decoration: none;
}

.btn:hover {
  background: #3cb0fd;
  background-image: -webkit-linear-gradient(top, #3cb0fd, #3498db);
  background-image: -moz-linear-gradient(top, #3cb0fd, #3498db);
  background-image: -ms-linear-gradient(top, #3cb0fd, #3498db);
  background-image: -o-linear-gradient(top, #3cb0fd, #3498db);
  background-image: linear-gradient(to bottom, #3cb0fd, #3498db);
  text-decoration: none;
}
</style>


</head>

<body bgcolor=black text=white>
  <h1><u><center>Student Attendance Management System</center></u></h1><div id='cssmenu'>

  <center><h3><b>Sign Up</b></h3></center>
    <?php
			if ( isset($errMSG) ) {
				
				?>
				<div class="form-group">
            	<div style="color:green;text-align:center" class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span></span> <?php echo $errMSG; ?>
                </div>
            	</div>
                <?php
			}
			?>
  <div class="form1">
	<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">
		<center>
			<b>Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b><input class="she" type="text"  name="name" /></br>
			<span style="color:red" class="text-danger"><?php echo $nameError; ?></span></br></br>

			<b>Faculty Id &nbsp;</b><input class="she" name="email" type="text"/></br>
			<span style="color:red" class="text-danger"><?php echo $emailError; ?></span></br></br>
			<b>Password  &nbsp;&nbsp;</b><input class="she" name="pass" type="text"/></br>
			<span style="color:red" class="text-danger"><?php echo $passError; ?></span><br/><br/>
			<b>Hint &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b><input class="she" name="hint" type="text"/><br/>
			<span style="color:red" class="text-danger"><?php echo $nameError; ?></span></br></br>
			<b><input style="padding:5px" type="submit" class="btn" name="btn-signup" value="Sign Up" /></b>
			<b><input style="padding:5px" type="Reset" class="btn" value="Reset"/></b></br></br>

		</center>
		<center><a href="index.php">Login</a></center>
	</form>
	 
</div>
</br>



<marquee><u><b>Nitte Meenakshi Institute Of Technology</b></u></marquee>

</body>
<html>



<?php
session_start();

$user=$_SESSION['user'];
	
?>

<!doctype html>
<html lang=''>
<head>
     <link rel="stylesheet" href="styles.css">
     
   <title>EDIT Student</title>
<style>
.form1{
margin-left:200px;
margin-right:200px;
border:1px solid white; 
padding-left:25px;
padding-top:10px;
padding-bottom:10px;
}
.she{
padding-left:5px;
font-size:bold;
}
</style>
<script>

</script>
</head>

<body bgcolor=black text=white>

  

<h1><u><center>Student Management System</center></u></h1><div id='cssmenu'>

<ul>

   <li> <a  href='home.php' style="background-color:grey;"><span>Home</span></a></li>
 
   <li class='active has-sub'><ul><li class='has-sub'></li></ul></li>
   <li><a href='Add_student.php'><span>Add Student</span></a></li>
   <li><a href='View_student.php'><span>View Student</span></a></li>
   
   <li class='last'>
        <a href='contact.html'><span>Contact</span></a></li>
   <li><a href='help.html'><span>Help</span></a></li>

    <li></li>


<li class='active has-sub'>
<a style="text-transform:uppercase;" href='#'><span><?php
if($_SESSION["user"]){
	?>
	WELCOME <?php echo $_SESSION["user"]; ?>

<?php
}
	?></span></a>
     
                       <ul>
         <li class='has-sub'>
                         
 <li><a href="logout.php?logout"><span>Log Out</span></a></li>

                                                    <ul>
              
            </ul>
         </li>
</li>


</ul></div>


<center><h3><b>Edit Student</b></h3></center>


<?php 
include('dbconnect.php');

$std_id=$_GET['id'];
  
  

              $n = $_POST['n'];
              $e = $_POST['e'];
			  $b = $_POST['b'];
              $add = $_POST['add'];
			  $mob = $_POST['mob'];
              $gen = $_POST['gen'];
if($n==""){
	echo "Enter the name";	
}else if($e==""){
	echo "Enter the email";
}else if($b==""){
	echo "Enter the branch";
}else if($add==""){
	echo "Enter the address";
}else if($mob==""){
	echo "Enter the mobile";
}else if($e=="gen"){
	echo "enter the gentder";
}
else{



	$i = mysql_query("update `".$user."` set name='$n', email='$e', branch='$b', address='$add', mobile='$mob', gender='$gen' where id='$std_id'");
      
	   if($i==true){
        echo 'Update Sccessfull';
        }
}
?>
<html>

	<body>
		<center>
		
  
<link rel="stylesheet" href="style.css"/>
	<body>
		<form method="post" enctype="multipart/form-data">
		  	<?php
		$id = $_GET['id'];
		include ("dbconnect.php");
		$i ="select * from `".$user."` where id=".$id;
		$h= mysql_query($i);
		if($tr=mysql_fetch_array($h))
		{
	?>
			<table border="1">
			<tr>
				<Td>Name</td>
				<td><input type="text"  value="<?php echo $tr[1]; ?>" name="n" required/></td>
			</tr>
			<tr>
				<Td>Email</td>
				<td><input type="email" value="<?php echo $tr[2]; ?>" name="e" required/></td>
			</tr>
			<tr>
				<Td>Branch</td>
				<td><input type="tex" name="b" value="<?php echo $tr[3]; ?>" name="b" required/></td>
			</tr>
			<tr>
				<Td>Address</td>
				<td><textarea cols="16" rows="3" name="add"> <?php echo $tr[4];?> </textarea></td>
			</tr>
			
			<tr>
				<Td>Mobile</td>
				<td><input type="text" pattern="[0-9]*" maxlength="10" name="mob" value="<?php echo $tr[5]; ?>" required/></td>
			</tr>
			<tr>
				<Td>gender</td>
				<td>
				male<input type="radio"  name="gen" value="m" required/>
				female<input type="radio"  name="gen" value="f" required/>
				</td>
			</tr>
			
			
			
			
			<tr>
				<td colspan="2">
				<input type="submit" class="bt" name="upd" value="Submit"/>
				<input type="reset" class="bt" name="re" value="Reset"/>
				</td>
			</tr>
			</table>
			  <?php
				}
				else
				{
					echo " error ";
				}
			
			?>
		</form>

</center>





<marquee><u><b>Nitte Meenakshi Institute Of Technology</b></u></marquee>

</body>
</html>
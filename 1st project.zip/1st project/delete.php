<?php
session_start();

$user=$_SESSION['user'];
?>

<!doctype html>
<html lang=''>
<head>
     <link rel="stylesheet" href="styles.css">
     <?php 
	 ob_start();
	  include ("dbconnect.php");
	
	
		 
		 
		  $del=$_GET['id'];
		 
		  $delete=mysql_query("DELETE FROM `".$user."` WHERE id='$del'");
		  if($delete)
		  {
			  print '</br>';
			  print '</br>';
			  print '</br><center>';
			  print '<h1>Regno>.:';
			  
			  echo $del;
			  print ' Record deleted successfully';
			  print '</h1></center>';
		  }
		  else
		  {
			  echo mysql_error();
	      }
	  
	  
	  ob_end_flush();
	  
	 
	 ?>
   <title>CSS MenuMaker</title>
<style>

</style>

</head>

<body bgcolor=black text=white>


</body>
<html>




<!doctype html>
<html lang=''>
<head>
     <link rel="stylesheet" href="styles.css">
     
   <title>Attendence</title>
<style>
.form1{
margin-left:200px;
margin-right:200px;
border:1px solid white; 
padding-left:25px;
padding-top:10px;
padding-bottom:10px;
}
.she{
padding-left:5px;
font-size:bold;
}
</style>
<script>

</script>
</head>

<body bgcolor=black text=white>

 
<h1><u><center>Student Attendance Management System</center></u></h1><div id='cssmenu'></h1>

<ul>

   <li>
<a  href='index.html'><span>Home</span></a>
</li>
 

  <li class='active has-sub'>
<a href='#'><span>Student</span></a>
     
                       <ul>
         <li class='has-sub'>
                          <a href='Add_student.php'><span>Add Student</span></a>
 <li><a href='View_student.php'><span>View Student</span></a></li>

               <li><a href='Modify_student.html'><span>Modify or Delete Student</span></a></li>

                                      <ul>
              
            </ul>
         </li>
    
          
    <ul>
                           </ul>
         </li>
      </ul>
   </li>
 
<li class='active has-sub'>

     
                       <ul>
         <li class='has-sub'>


                                      <ul>
               <li><a href='Add_student.php'><span>Add Student</span></a></li>
            </ul>
         </li>
    
     <li class='has-sub'><a href=''><span>add faculty</span></a>
        
    <ul>
               <li><a href='#'><span>new faculty </span></a></li>
               <li class='last'><a href='#'><span>view faculty</span></a></li>
            </ul>
         </li>
      </ul>
   </li>
 



<li><a href='#'><span>Attendence</span></a></li>
   <li>
<a  href='#'><span>Report</span></a>
</li>
   
<li class='last'>
<a href='#'><span>Contact</span></a></li>
 <li><a href='#'><span>Help</span></a></li>



<li class='active has-sub'>
<a href='index.html'><span>Settings</span></a>
     
                       <ul>
         <li class='has-sub'>
                          <a href='Add_student.html'><span>Change Password</span></a>
 <li><a href='logout.php?logout'><span>Log Out</span></a></li>

                                                    <ul>
              
            </ul>
         </li>






</ul>
</div>


<center><h3><b>Addendence</b></h3></center>
<div class="form1">
<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">
 <?php
			if ( isset($errMSG) ) {
				
				?>
				<div class="form-group">
            	<div style="color:green;text-align:center" class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span></span> <?php echo $errMSG; ?>
                </div>
            	</div>
                <?php
			}
			?>
<center>
<label></label>
<table border="2">
 <tr>
 <td>&nbsp;&nbsp;&nbsp;&nbsp;ID &nbsp;&nbsp;&nbsp;&nbsp;</td>
  <td> &nbsp;&nbsp;&nbsp;&nbsp;Name&nbsp;&nbsp;&nbsp;&nbsp;</td>
  <td> &nbsp;&nbsp;&nbsp;&nbsp;Attendence&nbsp;&nbsp;&nbsp;&nbsp;</td>
 </tr>
   <td></td>
  <td> </td>
 <tr>

 </tr>
 <?php
			session_start();
			include "dbconnect.php";
			$i = "select * from veena";
			$h = mysql_query($i);
			while($tr=mysql_fetch_array($h))
			{
		?>
        <tr>
        	<td><?php echo $tr[0]; ?></td>
            <td><?php echo $tr[1]; ?></td>
          
        
            <td align="center"><a href="Delete_Form.php? txtid=<?php echo $tr[0];?>"><input type="checkbox" name="att"/></a> / <a href="Modify_student.php? txtid=<?php echo $tr[0];?>"><input type="checkbox" name="att"/></a> </td>    
        </tr>
        <?php
			}
		?>
		
</table>
 


</center>

</form>
</div>

</br>
</br>
</br>
</br>





<marquee><u><b>Nitte Meenakshi Institute Of Technology</b></u></marquee>

</body>
</html>
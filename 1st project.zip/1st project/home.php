<?php
session_start();
?>


<!doctype html>
<html lang=''>
<head>
     <link rel="stylesheet" href="styles.css">
     
   <title>Home</title>


</head>

<body bgcolor=black text=white style="">


<h1><u><center>Student Management System</center></u></h1><div id='cssmenu'>

<ul>

   <li> <a  href='home.php' style="background-color:grey;"><span>Home</span></a></li>
 
   <li class='active has-sub'><ul><li class='has-sub'></li></ul></li>
   <li><a href='Add_student.php'><span>Add Student</span></a></li>
   <li><a href='View_student.php'><span>View Student</span></a></li>
   
   <li class='last'>
        <a href='contact.html'><span>Contact</span></a></li>
   <li><a href='help.html'><span>Help</span></a></li>

    <li></li>


<li class='active has-sub'>
<a style="text-transform:uppercase;" href='#'><span><?php
if($_SESSION["user"]){
	?>
	WELCOME <?php echo $_SESSION["user"]; ?>

<?php
}
	?></span></a>
     
                       <ul>
         <li class='has-sub'>
                         
 <li><a href="logout.php?logout"><span>Log Out</span></a></li>

                                                    <ul>
              
            </ul>
         </li>
</li>


</ul>
</div>
<div style="height:200px;width:100%; background-image:url('img/professional.jpg');background-position:center;">
     <div style="margin-top:70px;margin-left:100px;padding:10px;width:75%;;background-color:rgba(217, 217, 217, 0.15);">
		<p style="text-align:justify">
		These systems vary in size, scope and capability, from packages that are implemented in relatively small organizations to cover student records alone, to enterprise-wide solutions that aim to cover most aspects of running large multi-campus organizations and their online schools with significant local responsibility. Many systems can be scaledto different levels of functionality by purchasing add-on "modules" and can typically be configured by their home institutions to meet local needs.
		</br>
		<ul>
		<li>Maintainance of student database</li>
		<li>Facilating through Add, Update, Delete and View the student details.</li>
        <li>Authenticated access.</li>
		</ul>
		
		</p>
	 
	 </div>
	 
</div>

</br>





<marquee><u><b>Nitte Meenakshi Institute Of Technology</b></u></marquee>

</body>
<html>

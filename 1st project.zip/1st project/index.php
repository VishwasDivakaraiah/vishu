<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// it will never let you open index(login) page if session is set
	if ( isset($_SESSION['user'])!="" ) {
		header("Location: index.php");
		exit;
	}
	
	$error = false;
	
	if( isset($_POST['btn-login']) ) {	
		
		// prevent sql injections/ clear user invalid inputs
		$email = trim($_POST['email']);
		$email = strip_tags($email);
		$email = htmlspecialchars($email);
		
		$pass = trim($_POST['pass']);
		$pass = strip_tags($pass);
		$pass = htmlspecialchars($pass);
		// prevent sql injections / clear user invalid inputs
		
		if(empty($email)){
			$error = true;
			$emailError = "Please enter your email address.";
		} else if ( !filter_var($email,FILTER_VALIDATE_EMAIL) ) {
			$error = true;
			$emailError = "Please enter valid email address.";
		}
		
		if(empty($pass)){
			$error = true;
			$passError = "Please enter your password.";
		}
		
		// if there's no error, continue to login
		if (!$error) {
			
			// password hashing using SHA256
		
			$res=mysql_query("SELECT username,userid,password,hint FROM login WHERE userid='$email' AND password='$pass'");
			$row=mysql_fetch_array($res);
			$count = mysql_num_rows($res); // if uname/pass correct it returns must be 1 row
			
			if( $count == 1 ) {
				$_SESSION['user'] = $row['username'];
				
				echo $_SESSION["username"];
				header("Location: home.php");
				
			} else {
				$errMSG = "Incorrect Credentials, Try again...";
				
			}

				
		}
		
	}
	

?>




<html>
<head>
<title>project</title>
<script>
  function fun(){
alert("This is the clue<?php echo $hint ?>");
}
</script>
<style>
 .abc{
     border:2px solid white;
     background-color:black;
height:300px;
width:350px;
float:right;

}
.cba{

   text-align:center;
   margin-top:30px;
   margin-bottom:30px;
   margin-right:30px;
   margin-left:30px;
}
.har{
   border:2px solid white;
   background-color:black;
   height:300px;
   width:450px;
   float:left;
}
.he{
    color:black;
    }
.she
{
height: 25px;
  
                    display: block;
  
                    border: 1px solid;
  
                    border-radius: 5px;
  
                    width: auto;
                    
  
                    border-color: #080808;
 
                    margin: 0;
  
                    padding: 0;
padding-left:5px;

}

.para{
padding-right:20px;
padding-left:20px;
font-size:15pt;
}

.he{
color:white;
}
</style>
</head>

<body bgcolor="grey" text="white">


<form class="cba" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off"><center>


<h1 class="he"><u>Student Attendance Management System</u></h1> 
<div class="har">
<div style="height:250px;width:100%; background-image:url('img/professional.jpg');background-position:center;">


<h3 class="he"><u><b>About</b></u></h3>
<p class="para">Attendance management system is used to make the attendance register in</p>
</div>
</div>

<div class="abc">
<?php echo $errMSG; ?>
<h3 ><u><b> Login</b></u></h3>
Username:<input type="text"  name="email" class="she"/>
<span style="color:red" class="text-danger"><?php echo $emailError; ?></span><br/><br/>

Password:<input type="password"  name="pass" class="she"/>
<span style="color:red" class="text-danger"><?php echo $passError; ?></span><br/><br/>

<a href=""> <label name="forget" onclick="fun()">Forgot Password</label></a><br/>
<a href="regestrate.php"> <label onclick="">Sign In</label></a><br/><br/>

<input type="submit" value="Login" name="btn-login"/>
<input type="reset" value="Reset"/></center>
</div><br/><br/><br/><br/> <br/><br/>
<marquee><u><b>Nitte Meenakshi Institute Of Technology</b></u></marquee>
</form>

</body>


</html> 

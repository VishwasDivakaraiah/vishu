<?php
session_start();

$user=$_SESSION['user'];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Search by ID</title>
	<link rel="stylesheet" type="text/css" href="css/viewtablesearch.css" />
</head>

<body>
<center><h1>Search Result</h1></center>
<a class="addnew" href="index.php" style="font-face:Khmer OS Battambang; font-size:16px;"></a></font>
	<table>
    	<tr>
            <th>StuID</th>
            <th>StuName</th>
            <th>email</th>
            <th>Branch</th>
            <th>Address</th>
            <th>Ph No.</th>
            <th>Gender</th>
            
           
            <th>Option</th>
        </tr>
    <?php
		$text = $_POST['txtsearch'];
		if($text==""){
			echo "No Data....Please Try Again!!!"."<br>";
			echo '<a href="View_student.php">Go Back</a>';
		}
	?>
    <?php
		$cbo = $_POST['cbosearch'];
		$search = $_POST['txtsearch'];
		include('dbconnect.php');
	?>
    <?php
		if($cbo=="ID")
		{
			$id = mysql_query("SELECT * FROM `".$user."` WHERE id='$search'");
	?>

    <?php
		while($di=mysql_fetch_array($id))
		{
	?>
			<tr>
				<td><?php echo $di[0]; ?></td>
				<td><?php echo $di[1]; ?></td>
                <td><?php echo $di[2]; ?></td>
                <td><?php echo $di[3]; ?></td>
                <td><?php echo $di[4]; ?></td>
                <td><?php echo $di[5]; ?></td>
                <td><?php echo $di[6]; ?></td>
				<td align="center"><a href="Delete_Form.php? txtid=<?php echo $di[0];?>">Delete</a> / <a href="Edit_Form.php? txtid=<?php echo $di[0];?>">Edit</a></td>
			</tr>
            <?php
		}
		}else if($cbo=="Name")
		{
			$na = mysql_query("SELECT * FROM `".$user."` WHERE name like '".$search."%'");
	?>
    <?php
		while($an=mysql_fetch_array($na))
		{
	?>
			<tr>
				<td><?php echo $an[0]; ?></td>
				<td><?php echo $an[1]; ?></td>
                <td><?php echo $an[2]; ?></td>
                <td><?php echo $an[3]; ?></td>
                <td><?php echo $an[4]; ?></td>
                <td><?php echo $an[5]; ?></td>
                <td><?php echo $an[6]; ?></td>
				<td align="center"><a href="Delete_Form.php? txtid=<?php echo $an[0];?>">Delete</a> / <a href="Edit_Form.php? txtid=<?php echo $an[0];?>">Edit</a></td>
			</tr>
           
     
            
            <?php
				}
		}
			?>
</table>
</body>
</html>
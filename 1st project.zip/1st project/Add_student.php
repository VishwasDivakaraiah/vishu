<?php
session_start();	
?>


<!doctype html>
<html lang=''>
<head>
     <link rel="stylesheet" href="styles.css">
     
     <title>ADD Student</title>
<style>
input,textarea{width:220px}
.form1{
          margin-left:200px;
          margin-right:200px;
          border:1px solid white; 
          padding-left:25px;
          padding-top:10px;
          padding-bottom:10px;
}
.she{
          padding-left:5px;
          font-size:bold;
}
</style>

</head>

<body bgcolor=black text=white>

<?php

include('dbconnect.php');
$user = $_SESSION["user"];

extract($_POST); 
if($save)
{
//check user already exists or not
echo $_SESSION["username"];
$q=mysql_query("select email from `".$user."` where email='$e'");
$r=mysql_num_rows($q);
if($r)
{
echo "<font color='red'>$e already exists</font>";
}
else
{

//for image
$img=$_FILES['img']['name'];


//dob
$dob=$yy."-".$mm."-".$dd;

//save data
$query="insert into `".$user."` values('','$n','$e','$b','$add','$mob','$gen','$img','$dob',now())";
mysql_query($query);

//save user's image
mkdir("image/$e");
move_uploaded_file($_FILES['img']['tmp_name'],"image/$e/".$_FILES['img']['name']);

echo "<font color='blue'>Congrates !</font>";
}
}
?>



<h1><u><center>Student Management System</center></u></h1><div id='cssmenu'>

<ul>

   <li> <a  href='home.php' ><span>Home</span></a></li>
 
   <li class='active has-sub'><ul><li class='has-sub'></li></ul></li>
   <li><a style="background-color:grey;" href='Add_student.php'><span>Add Student</span></a></li>
   <li><a href='View_student.php'><span>View Student</span></a></li>
   
   <li class='last'>
        <a href='contact.html'><span>Contact</span></a></li>
   <li><a href='help.html'><span>Help</span></a></li>

    <li></li>


<li class='active has-sub'>
<a style="text-transform:uppercase;" href='#'><span><?php
if($_SESSION["user"]){
	?>
	WELCOME <?php echo $_SESSION["user"]; ?>

<?php
}
	?></span></a>
     
                       <ul>
         <li class='has-sub'>
                         
 <li><a href="logout.php?logout"><span>Log Out</span></a></li>

                                                    <ul>
              
            </ul>
         </li>
</li>


</ul>
</div>


<center><h3><b>Add New Student</b></h3></center>


<center>
<link rel="stylesheet" href="style.css"/>
	<body>
		<form method="post" enctype="multipart/form-data">
			<table border="1">
			<tr>
				<Td>Name</td>
				<td><input type="text" name="n" required/></td>
			</tr>
			<tr>
				<Td>Email</td>
				<td><input type="email" name="e" required/></td>
			</tr>
			<tr>
				<Td>Branch</td>
				<td><input type="tex" name="b" required/></td>
			</tr>
			<tr>
				<Td>Address</td>
				<td><textarea name="add" required></textarea></td>
			</tr>
			
			<tr>
				<Td>Mobile</td>
				<td><input type="text" pattern="[0-9]*" maxlength="10" name="mob" required/></td>
			</tr>
			<tr>
				<Td>gender</td>
				<td>
				male<input type="radio"  name="gen" value="m" required/>
				female<input type="radio"  name="gen" value="f" required/>
				</td>
			</tr>
			
			
			<tr>
				<Td>Dob</td>
				<td>
				<select  name="yy" required>
					<option value="" selected="selected" disabled="disabled">Year</option>
				<?php 
				for($i=1900;$i<=2015;$i++)
				{
				echo "<option value='$i'>".$i."</option>";
				}
				?>	
				</select>	
				<select  name="mm" required>
					<option value="" selected="selected" disabled="disabled">Month</option>
				<?php 
				for($i=1;$i<=12;$i++)
				{
				echo "<option value='$i'>".$i."</option>";
				}
				?>	
				</select>
				<select  name="dd" required>
					<option value="" selected="selected" disabled="disabled">Year</option>
				<?php 
				for($i=1;$i<=31;$i++)
				{
				echo "<option value='$i'>".$i."</option>";
				}
				?>	
				</select>		
				</td>
			</tr>
			<tr>
				<Td>Image</td>
				<td><input type="file" name="img" required></td>
			</tr>
			<tr>
				<td colspan="2">
				<input type="submit" class="bt" name="save" value="Submit"/>
				<input type="reset" class="bt" name="re" value="Reset"/>
				</td>
			</tr>
			</table>
		</form>
	</body>
</center>

<marquee><u><b>Nitte Meenakshi Institute Of Technology</b></u></marquee>

</body>
</html>


-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2017 at 11:25 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `branch`
--

-- --------------------------------------------------------

--
-- Table structure for table `kumar`
--

CREATE TABLE IF NOT EXISTS `kumar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `mobile` bigint(20) DEFAULT NULL,
  `gender` enum('m','f') NOT NULL,
  `image` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `regDate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `kumar`
--

INSERT INTO `kumar` (`id`, `name`, `email`, `branch`, `address`, `mobile`, `gender`, `image`, `dob`, `regDate`) VALUES
(1, 'kumbi', 'kumbi@gmail.com', 'mca', 'shdjsbdf', 9089556135, 'm', 'WIN_20160102_020835.JPG', '1916-10-17', '2017-01-20 09:02:38');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(15) NOT NULL,
  `password` varchar(20) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `hint` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `userid`, `hint`) VALUES
('ashok', 'ashokreddy', 'ashok1995@gmail.com', 'hint'),
('reddy', 'ashokreddy', 'reddy@gmail.com', 'hint'),
('asdsdf', 'sdgfvdgdf', 'asfds@gmail.com', 'dfgdfgfd'),
('asfdsf', 'dfhgfj', 'fdgdf@gdf.com', 'ghkhj'),
('rtfhnft', 'setgdfh', 'gtfdh@dfg.dfh', 'dfgf'),
('fghjgj', 'fhfgjgjgh', 'ghfjf@gh.ghjghj', 'gjghjgh'),
('fghjgj', 'fhfgjgjgh', 'ghfjf@gh.ghjghj', 'gjghjgh'),
('fghjgj', 'fhfgjgjgh', 'ghfjf@gh.ghjghj', 'gjghjgh'),
('ressy', 'safsdf', 'ressy@gmail.com', 'asdds'),
('xdb', 'dgfdfhd', 'dfhfgh@dfg.sdg', 'dfg'),
('szc', 'fgfhghf', 'dfdg@fj.gh', 'fhfhfgh'),
('dfhfh', 'sfdgdfh', 'hfgh@gdh.fg', 'sdgf'),
('dfhbgfh', 'fghngj', 'dgdf@tgh.gj', 'segdrfgdfh'),
('ashok', 'dgdfhgf', 'sdfs@fdhgf.gfhgf', 'dhfghfg'),
('ashok', 'dfhdfhfg', 'dfgfd@fg.hkg', 'sdhfhfg'),
('ashok', 'ashokreddy', 'ashokfdg@gmail.com', 'sdfdg'),
('veena', 'dfhgdh', 'sdfgdg@dfh.fh', 'dfhfghf'),
('srini', 'ashokreddy', 'srini@gmail.com', 'ashok'),
('vishwas', 'vishwas', 'vishuvishwasa@gmail.', 'harry'),
('ashok', 'ashokreddy', 'ashok19@gmail.com', 'ashhgj'),
('abcd', 'abcd123', 'abcd@gmail.com', '123'),
('reddy', 'reddy214', 'reddy214@gmail.com', 'hafshd'),
('kumar', 'kumar123', 'kumar@nmit.com', 'kumar'),
('harshith', 'harshith', 'harshith@gmail.com', 'harshi'),
('reddy', 'ashokreddy', 'reddy@nmit.com', 'reddy');

-- --------------------------------------------------------

--
-- Table structure for table `reddy`
--

CREATE TABLE IF NOT EXISTS `reddy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `mobile` bigint(20) DEFAULT NULL,
  `gender` enum('m','f') NOT NULL,
  `image` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `regDate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `gender` enum('m','f') NOT NULL,
  `image` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `regDate` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `mobile` (`mobile`),
  UNIQUE KEY `email_2` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `branch`, `address`, `mobile`, `gender`, `image`, `dob`, `regDate`) VALUES
(1, 'harshith', 'harshith@gmail.com', 'mca', 'jalahalli', 9876543215, 'm', 'Chrysanthemum.jpg', '1901-02-02', '2015-03-20 12:46:04'),
(2, 'ravi', 'ravi@gmai.com', 'ddd', 'america', 7777777777, 'm', 'Desert.jpg', '1901-02-03', '2015-03-20 12:48:42'),
(3, 'shilpi', 'shilpi@gmail.com', 'shilip', 'noia', 888888, 'f', 'Hydrangeas.jpg', '1916-08-17', '2015-03-20 12:49:15'),
(4, '', '', '', '', 0, '', 'Jellyfish.jpg', '1901-03-02', '2015-03-20 12:49:38'),
(5, 'soni', 'soni@gmail.com', 'soni', 'kkkkkkk', 6666666666, 'f', 'Koala.jpg', '1902-02-03', '2015-03-20 12:50:00'),
(6, 'ajay devgan', 'ajay@gmail.com', 'ajay', 'srinagar', 709870808, 'm', 'Koala.jpg', '1902-03-03', '2015-03-20 12:50:27'),
(7, 'ashok reddy', 'ashok1995@gail.com', 'ASHOK', '								sdffgdfg								', 986575989, 'm', 'IMG_20160702_071418.jpg', '1914-03-17', '2016-12-30 19:39:57'),
(8, 'ashok', 'ashok19952@gail.com', 'sdfsdc', 'sdfs', 985654, 'm', 'WIN_20161208_13_09_50_Pro.jpg', '1913-02-13', '2016-12-30 20:18:23'),
(9, 'ashok', 'ashok199@gail.com', 'mca', 'skejfdj', 96544, 'm', 'WIN_20160102_020748.JPG', '1909-02-10', '2016-12-30 20:45:43'),
(10, 'ashok', 'fgvdf@gmail.com', 'awyjg', '62236354', 9008965, 'm', 'WIN_20160102_020750.JPG', '1911-02-13', '2016-12-30 20:47:53'),
(11, 'puli', 'ashok19935@gail.com', 'mca', 'xdgdfg', 98659643, 'm', 'WIN_20160102_020931.JPG', '1911-03-14', '2016-12-30 20:57:39');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
